total = float(input("Enter total bill amount: "))
people = int(input("Enter number of people: "))
per_person = total / people
print("Each person should pay:", round(per_person, 2))