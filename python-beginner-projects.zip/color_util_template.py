def red(text): return f"\033[31m{text}\033[0m"
def green(text): return f"\033[32m{text}\033[0m"
def yellow(text): return f"\033[33m{text}\033[0m"
def blue(text): return f"\033[34m{text}\033[0m"
def magenta(text): return f"\033[35m{text}\033[0m"
def cyan(text): return f"\033[36m{text}\033[0m"
def bold(text): return f"\033[1m{text}\033[0m"
def underline(text): return f"\033[4m{text}\033[0m"

if __name__ == "__main__":
    print(green("✅ Success: You passed the test!"))
    print(red("❌ Error: Something went wrong."))
    print(yellow("⚠️ Warning: Check your inputs."))
    print(bold("This is bold text."))
    print(underline("This is underlined text."))