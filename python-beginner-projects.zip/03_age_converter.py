age = int(input("Enter your age in years: "))
months = age * 12
days = age * 365
hours = days * 24
print("You are", months, "months,", days, "days, and", hours, "hours old.")