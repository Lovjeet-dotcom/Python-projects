from color_util_template import green, red

name = input("Student name: ")
math = int(input("Math marks: "))
sci = int(input("Science marks: "))
eng = int(input("English marks: "))

total = math + sci + eng
average = total / 3

print("Total:", total)
print("Average:", average)

if math >= 33 and sci >= 33 and eng >= 33:
    print(green("Result: Pass ✅"))
else:
    print(red("Result: Fail ❌"))