# 💻 Python Beginner Projects by Lovjeet Singh

Welcome! This is a growing collection of beginner-friendly Python programs made while learning Python from scratch. Each project applies real-world logic, user input, and basic programming concepts.

## 📁 Projects List

| Project                         | Description                                 |
|--------------------------------|---------------------------------------------|
| `01_bmi_calculator.py`         | Calculates your BMI based on height & weight |
| `02_bill_splitter.py`          | Splits a total bill equally among people    |
| `03_age_converter.py`          | Converts your age to months, days, hours    |
| `04_movie_ticket_pricing.py`   | Shows ticket cost based on age              |
| `05_intro_generator.py`        | Generates a custom student introduction     |
| `06_report_card.py`            | Mini marksheet with pass/fail logic         |

## 🎨 Colors in Output

To make output cleaner and more professional, these projects use:
- `color_util_template.py` for reusable functions like `green()`, `red()`, `bold()`, etc.

## 🚀 How to Run

1. Clone this repo:
```bash
git clone https://github.com/your-username/python-beginner-projects.git
cd python-beginner-projects
```

2. Run any file:
```bash
python 01_bmi_calculator.py
```

## 📌 Skills Used

- Python basics (`input`, `print`, variables, if-else)
- Type conversion
- Terminal text styling
- Code modularity

## 🧠 Author

Made with 💙 by Lovjeet Singh  
[LinkedIn](https://www.linkedin.com/in/your-link) | [GitHub](https://github.com/your-username)